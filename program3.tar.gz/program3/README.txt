To run:
python3 feature_extraction.py <file1> <file2>
