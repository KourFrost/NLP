A) Language Python3 
B) 
    For -test
        python3 langmodels.py train2.txt -test test2.txt
    For -Gen
        python3 langmodels.py train2.txt -gen seeds.txt 
C) untested on CADE
D) no known bugs or limitations