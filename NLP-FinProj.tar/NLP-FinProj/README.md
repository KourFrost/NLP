   NLP-FinProj
=================
Final Project for [UofU Fa21 CS 5340 - Natural Language Processing]. Where we create an Information Extraction System for cooperate acquisition information. 

1. A list of all external resources (libraries, software, knowledge bases, or other tools) that your system uses, along with a URL or citation for each one that tells us what it is and where it came from.
    
    - Python3 (python 3.8 or newer is preferred)
    - Spacy w/ the basic `en_core_web_sm` Language kit
      - The `IE-script.txt` should try to install it loccally, but spacy was on the CADE machines we used (1 & 4), you might just needed to run:
        ```bash
        python3 -m spacy download en_core_web_sm
        ```

2. A time estimate of how long your system takes to process ONE document. (This will give the TAs an estimate of how long they should expect to wait to see the results.)

        usually just under 3 seconds 
        (on my machine might be more especially if you don't have the tensor core setup)

3. For 2-person teams, please list which parts of the system each team member substantially contributed to.

    - Both
      - File handling helper functions
    - Andrew Osterhout (u1317172):
      - NP identifier helper function
      - Best choice selector functions
      - `IE-script.txt`
      - Presentation P1
      - The Interfaces between the two halves of the program.
      - IE of:
        - `ACQUIRED`
        - `SELLER`
        - `PURCHASER`
    - JT Herrmann (u0259542):
      - Presentation P2
      - IE of:
        - `ACQLOC`
        - `ACQBUS`
        - `DLRAMT`
        - `STATUS`
<!-- Andrew- spacy integration, pipeline architecture, file organization
JT- I/O, pattern extractions -->

1. Please explain any known problems or limitations of your system.

    - General:
      - Can't identify more than one party per field (aka only one of two sellers _etc._) 
    - Andrews System:
      - the patterns don't include context so they just fill with common patterns
      - the patterns don't work if the sentences with the verbs for the objects don't contain the proper noun (_aka_ not a pronoun).
    - JT's System:
      - doesnt account for context
      - patterns really heavliy on common phrases
      - a few systems find valid canidates but dont have systems in place to identify the best canidate, so it picks a canidate in random


