#! /bin/python3.8

#* UofU Fa21 cs5340/cs6340
#*  Final Project - Cooperate Acquisition Info Extraction
#* Authors:
#*   - Andrew Osterhout (u1317172)
#*   - JT Herrmann (u0259542)

# << =========================================================================================== >> 
# <<                                           IMPORTS                                           >> 
# << =========================================================================================== >> 

# << =================================== NatLang Lib Imports =================================== >> 
# - Spacy Imports --------------------- 
import spacy
from spacy.tokens import Span

Lang = spacy.language.Language
NLP:Lang = spacy.load('en_core_web_sm')


# << ===================================== Utility Imports ===================================== >> 
import sys
from os.path import basename as p_basename


# << ===================================== Typing Imports ====================================== >> 
from typing import List, Dict, Tuple, Callable as λ, Union as Un


# << ================================= Our Helper Code Imports ================================= >> 
sys.path += ['./src/','./']
from src.helpers import process_file, write_answers

# - import Andrew's Work ------------------------- 
from src.andrew import andrews_stuff

# - import JT's Work ----------------------------- 
from src.DLRAMTcode import *
from src.ACQLOCcode import *
from src.STATUScode import *
from src.ACQBUScode import *


# << =========================================================================================== >> 
# <<                                          OUR CODE                                           >> 
# << =========================================================================================== >> 
"""
The main body of our code, just controls the flow of the program.

AUTHORS:
  Andrew Osterhout (u1317172)
  JT Herrmann (u0259542)
"""


# << ================================= Handle Input Parameters ================================= >> 
# - get doclist file path from cmd parameters ------------------------------ 
doclist_file = sys.argv[1] 
# - gets file paths to docs ------------------------------------------------ 
with open(doclist_file, 'r') as text: 
    doclist_fps = text.read().splitlines() 
# - Generate filepath & file for the output file --------------------------- 
output_file = p_basename(doclist_file) + '.templates'
# opening in write/overwrite mode
with open(output_file,'w') as tmp_out_file: 
    # writing to file to make sure it's created
    tmp_out_file.write('')  
# important because when we output later we only append
    
    
# << ========================== Proccess, Extract The Info -> Output =========================== >> 
for doc_fp in doclist_fps:
    # - Read in document contents ----------------------------------------- 
    doc = process_file(doc_fp, NLP)
    # - Set up Answers dict ----------------------------------------------- 
    answers:Dict[str,Un[Span,List[Span]]] = {'TEXT': p_basename(doc_fp)}    
    # - Extract `ACQUIRED`, `PURCHASER` & `SELLER` (Andrew) --------------- 
    andrews_stuff(doc, answers)
    # - Extract `ACQBUS`, `ACQLOC`, `DLRAMT` & `STATUS` (JT) -------------- 
    answers.update({'ACQBUS': getACQBUS(doc.text), 
                    'ACQLOC': getLOC(doc), 
                    'DLRAMT': getDlramt(doc), 
                    'STATUS': getSTATUS(doc.text)}) # tmp till JT inserts his stuff
    # JT Herrmann (u0259542)
    # - Write the results to the output file ------------------------------ 
    write_answers(output_file, answers)


# << =========================================================================================== >> 
# <<                                           THE END                                           >> 
# << =========================================================================================== >> 
