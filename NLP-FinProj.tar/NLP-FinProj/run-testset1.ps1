# Run from anywhere !!

# $curr="$pwd"

# cd "G:\My Drive\School\UofU\2021-3_Fall\cs5340_natLang\proj\NLP-FinProj\testset1"

python "G:\My Drive\School\UofU\2021-3_Fall\cs5340_natLang\proj\NLP-FinProj\extract.py" ./testset1/doclist.txt 
perl "G:\My Drive\School\UofU\2021-3_Fall\cs5340_natLang\proj\NLP-FinProj\scorer\score-ie.pl" ./doclist.txt.templates ./testset1/gold.templates

# cd "$curr"
