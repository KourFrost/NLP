#! /bin/python3-8

import os
import numpy as np

def is_num(value):
    value = value.replace(',', '')
    value = value.replace('.', '')
    is_num = value.isdecimal()
    if is_num:
        return 1
    return 0

def is_NUM(value):
    NUM_Values=['one','two','three','four','eight','nine','mln', 'billion']
    if value.lower() in NUM_Values:
        return 1
    return 0

def is_CUR(value):
    CUR_Values=['dlr', 'dlrs', 'stg', 'yen']
    if value.lower() in CUR_Values:
        return 1
    return 0

def is_WORD(value):
    WORD_Values=['undisclosed','undisclosed', 'withheld']
    if value.lower() in WORD_Values:
        return 1
    return 0

def is_WORD_WORD(value):
    WORD_WORD_Values=['not disclosed','not released', 'undisclosed sum','undisclosed terms']
    if value.lower() in WORD_WORD_Values:
        return 1
    return 0

def pattern_num_NUM_CUR (value):
    value_seperated = value.split()
    isWordLenth = len(value_seperated) != 3
    if isWordLenth:
        return 0
    is_pattern = is_num(value_seperated[0]) and is_NUM(value_seperated[1]) and is_CUR(value_seperated[2])
    if is_pattern:
        return 1
    return 0

def pattern_NUM_NUM_CUR (value):
    value_seperated = value.split()
    isWordLenth = len(value_seperated) != 3
    if isWordLenth:
        return 0
    is_pattern = is_NUM(value_seperated[0]) and is_NUM(value_seperated[1]) and is_CUR(value_seperated[2])
    if is_pattern:
        return 1
    return 0

def pattern_num_CUR (value):
    value_seperated = value.split()
    isWordLenth = len(value_seperated) != 2
    if isWordLenth:
        return 0
    is_pattern = is_num(value_seperated[0]) and is_CUR(value_seperated[1])
    if is_pattern:
        return 1
    return 0

def pattern_WORD(value):
    value_seperated = value.split()
    isWordLenth = len(value_seperated) != 1
    if isWordLenth:
        return 0
    is_pattern = is_WORD(value_seperated[0])
    if is_pattern:
        return 1
    return 0

def pattern_WORD_WORD(value):
    value_seperated = value.split()
    isWordLenth = len(value_seperated) != 2
    if isWordLenth:
        return 0
    is_pattern = is_WORD_WORD(value)
    if is_pattern:
        return 1
    return 0

DLRAMT = []
DLRAMT_doubles=[]

for filename in os.listdir("development-anskeys"):
    with open(os.path.join("development-anskeys", filename), 'r') as f:
        text = f.read()
        line_separated_text = text.splitlines()
        for line in line_separated_text:
            word_seperated_text = line.split()

            if len(word_seperated_text) > 0:

                if word_seperated_text[0] == "DLRAMT:":
                    dlramt_entry= line[7:]
                    if dlramt_entry !=  " ---":
                        DLRAMT.append(dlramt_entry)
                        double = dlramt_entry.split(' /')
                        for val in double:
                            DLRAMT_doubles.append(val)
patterns =[]
for val in DLRAMT_doubles:
    clean = val[1:].replace('"','')
    patterns.append(clean)

unPatterned=[]
#check for pattern of <#> <number> <currency>
for val in patterns:
    match = pattern_num_NUM_CUR(val) or pattern_WORD(val) or pattern_num_CUR(val) or pattern_WORD_WORD(val) or pattern_NUM_NUM_CUR(val)
    if not match:
        unPatterned.append(val)

for val in unPatterned:
    print(val)

