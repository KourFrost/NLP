import sys
from typing import Text
import spacy
from os import walk
import re
def replace(old, new, str, caseinsentive = False):
    if caseinsentive:
        return str.replace(old, new)
    else:
        return re.sub(re.escape(old), new, str, flags=re.IGNORECASE)

def duplicates(lst, item):
    return [i for i, x in enumerate(lst) if x == item]

   

def getKeys(file):
    file1 = open(file, 'r')
    Lines = file1.readlines()
    
    output = []
    for line in Lines:
        if len(line)> 3:
            info = line.split(':', 1)
            # print(info)
            hasValue = info[1] != ' ---\n'
            if hasValue:
                value = info[1].replace(' "','')
                value = value.replace('"\n','')
                key = '<'+info[0]+'>'
                output.append([key, value])
    return output
pathKey='../data/development-anskeys'

filenames = next(walk(pathKey), (None, None, []))[2]  # [] if no file

# print(len(filenames))

pathText='../data/development-docs'
nlp = spacy.load("en_core_web_sm")
norps = []
count = 0
for file in filenames:
    filePath = pathKey+'/'+file
    keys = getKeys(filePath)
    local= []
    # if file[:-4] == '3622':
    if True:
        for key in keys:
            if key[0] == '<ACQLOC>':
                if key[1] != '---':
                    
                #get text
                    docPath = pathText+'/'+file[:-4] 
                    doc = open(docPath, 'r').read()
                    nlpdoc =nlp(doc)
                    # print(nlpdoc)
                    # print('POS: ',  end = '')
                    # for tokens in nlpdoc:
                    #     print(tokens.pos_ +' ', end = '')
                    print('')
                    print('')
                    print(file[:-4])   
                    print(key[1])
                    print('ENT: ',  end = '')
                    
                    for ent in nlpdoc.ents:
                        # print(ent.text+':'+ent.label_+' ', end = '')
                        # norps.append(ent.text)
                        if ent.label_ in ('NORP', 'GPE') :
                            print(ent.text+':'+ent.label_+' ', end = '')
                            norps.append(ent.text)
                            local.append(ent.text)
                doc2 = doc.split()
                print('')
                for l in local:
                    sentanceIndex = duplicates(doc2, l)
                    print(l+':')
                    for index in sentanceIndex:
                        print('    ',nlpdoc[index-2], nlpdoc[index-1])


                if key[1] in norps:
                    count= count +1
print(str(count) + ' / '+str(len(norps)))
