with open('currencies.txt') as f:
        cur = set({l.strip('\n') for l in f.readlines()})

with open('CurData.txt', 'w') as f:
    for c in cur:
        f.write('%s\n' % c)