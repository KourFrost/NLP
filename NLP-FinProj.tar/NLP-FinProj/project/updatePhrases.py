from os import stat


with open('knownStatus.txt') as f:
        status = set({l.strip('\n') for l in f.readlines()})

print(len(status))

with open('gold.templates') as f:
        temp = set({l.strip('\n') for l in f.readlines()})

for tem in temp:
    if tem[:9] == 'STATUS: "':
        print('  t: ',tem[9:-1])
        status.add(tem[9:-1])

print(len(status))

print(status)

with open('knownStatus.txt', 'w') as f:
    for c in status:
        f.write('%s\n' % c)