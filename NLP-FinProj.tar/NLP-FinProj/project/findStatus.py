import random

####### get status Methods ################
def determinStatus(list):
    return random.choice(list)

def getSTATUS(doc):
    returnSTR = '---'
    with open('knownStatus.txt') as f:
        phrases = f.read().splitlines()
    validPhrases= []
    print(len(phrases))
    print(phrases)
    for phrase in phrases:
        if phrase in doc:
            validPhrases.append(phrase)
    print(validPhrases)
    if len(validPhrases)>0:
        returnSTR = determinStatus(validPhrases)

    if returnSTR != '---':
        returnSTR = '"'+returnSTR+'"'

    return returnSTR


text = "Allwaste Inc said it agreed in principle to acquire all outstanding stock of a company in the industrial service business for 1.98 mln dlrs in common stock. It did not identify the company to be acquired. Reuter"
value = getSTATUS(text)
print(value)