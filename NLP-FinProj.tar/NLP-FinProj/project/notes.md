  THE PLAN (2021/11/10)
=========================

 The process
---------------
1. Generate "gram" vectors [[`gen-data.py`](./src/gen-data.py)] Output in files in the [`./gen/`](./gen/) dir.
   - †`word_start`: char index of start of word in content
   - †`word_end`: char index of the character just after the last char in the word (usually a space)
   - `Word-1`: word-1
   - `Word`: word
   - `Word+1`: word+1
   - `POS-1`
   - `POS`
   - `POS+1`
   - `NERT-1`: NER Type -1
   - `NERT`: NER Type
   - `NERT+1`: NER Type +1
   - `NERT-1=?`: Is NER Type -1 Same?
   - `NERT+1=?`: Is NER Type +1 Same?
   - `NERID-1`: NER ID -1
   - `NERID`: NER ID 
   - `NERID+1`: NER ID +1
   - `NERID-1=?`: Is NER ID -1 Same?
   - `NERID+1=?`: Is NER ID +1 Same?
   - `Dep`: Dep Type
   - `Dep-P`: Dep Parent Type
   - `Dep-P-POS`: Dep Parent POS
   - `Num?`: Is a Number?
   - `Denom?`: Is a currency denom?
   - `Loc?`: Is a location?
   - `Org?`: Is Organization/Business Name?
   - `ACQUIRED?`: Is in ACQUIRED
   - `ACQBUS?`: Is in ACQBUS
   - `ACQLOC?`: Is in ACQLOC
   - `DLRAMT?`: IS in DLRAMT
   - `PURCHASER?`: Is in PURCHASER
   - `SELLER?`: Is in SELLER
   - `STATUS?`: Is in STATUS
   - † - this is necessary for building the vector should not be used to create any models (aka should be ignored)
2. perform statistical analysis on vectors as "n-grams" [[`train.py`](./src/train.py)]
3. find then compare to ans [[`train.py`](./src/train.py)]
4. generate patterns w/ context (+/- some number of words or leaps in dep-graph) [[`train.py`](./src/train.py)]
   - output models in to the [`./model/`](./model/) dir
5. Apply patterns to test data [[`extract.py`](./src/extract.py)]


 TODO
------
- Andrew
  - [ ] [`gen-data.py`](./src/gen-data.py)
    - [ ] get data for location tagging (NER might make this unessisary)
    - [ ] get data for business/organization tagging (NER might make this unessisary)
  - [ ] [`train.py`](./src/train.py) (step 4)
- JT
  - [ ] add other output and submit checkup 
  - [ ] start work on [`train.py`](./src/train.py) (steps 2-3)



 concepts & ideas
--------------------
- analyze phi and omega for sentences, 
  - as well as, possibly a start document marker & end of document marker (Phi & Omega?)
- Pattern Matching [[link](https://spacy.io/api/matcher)]
- Named Entity Recognition (NER)
   [[link](https://spacy.io/usage/linguistic-features#named-entities)]
   plus entity linking
   [[link](https://spacy.io/usage/linguistic-features#entity-linking)]