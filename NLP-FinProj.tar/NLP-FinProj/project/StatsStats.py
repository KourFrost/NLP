import sys
import os
import numpy as np

def output(name, dict):
    print(name)
    print('SIZE:', len(dict))
    key = max(dict, key=dict.get)
    print('MAX:',key, dict[key])
    print('MEAN:', np.mean(list(dict.values())))
    print('')

def addValue(key, dic):
    if key in dic:
        dic[key] = dic[key] + 1
    else:
        dic[key] = 1
    return dic

ACQ = {}
ACQBUS={}
ACQLOC={}
DLRAMT={}
PURCHASER={}
SELLER={}
STATUS={}

for filename in os.listdir("../data/development-anskeys"):
    with open(os.path.join("../data/development-anskeys", filename), 'r') as f:
        text = f.read()
        line_separated_text = text.splitlines()

        for line in line_separated_text:
            if line[:7] == "ACQBUS:":
                if line[7:] != ' ---':
                    text = line[7:].split(' / ')
                    for txt in text:
                        entry = txt.replace('"', '')
                        entry = entry.lstrip()
                        print(entry)
                        ACQBUS = addValue(entry, ACQBUS)

                # item_seperated_text = line.split('"')
                # entrySkip = True  
                # if len(item_seperated_text)>0:
                #     dict_value = item_seperated_text[0]
                #     for entry in item_seperated_text:
                #         if entrySkip:
                #             entrySkip = False
                #         else:
                #             entry = entry.replace('"', '')
                #             if entry != '---':
                #                 if dict_value == "STATUS:": 
                #                     STATUS = addValue(entry, STATUS)

# output('ACQUIRED', ACQ)
output('ACQBUS', ACQBUS)
print(STATUS)
# output('ACQLOC', ACQLOC)
# output('DLRAMT', DLRAMT)
# output('PURCHASER', PURCHASER)
# output('SELLER', SELLER)
# output('STATUS', STATUS)
# print(STATUS)

# for key, value in sorted(DLRAMT.items(), key=lambda item: item[1]):
#     print("%s: %s" % (key, DLRAMT[key]))

# print()
# print('********')
# print()


for key, value in sorted(ACQBUS.items(), key=lambda item: item[1]):
    print("%s: %s" % (key, ACQBUS[key]))


temp = open('knownIndustries.txt', 'w')
for values in ACQBUS:
    print(values)
    temp.write(values+'\n')
