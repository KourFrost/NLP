#! /bin/python3.8

#* UofU Fa21 cs5340/cs6340
#*  Final Project - Cooperate Acquisition Info Extraction
#* Authors:
#*   - Andrew Osterhout (u1317172)
#*   - JT Herrmann (u0259542)


# Add items you want to import with `from GLOBALS import *` to this `__all__` list

# << =========================================================================================== >> 
# <<                                           IMPORTS                                           >> 
# << =========================================================================================== >> 





# << =========================================================================================== >> 
# <<                                     GLOBALS & CONSTANTS                                     >> 
# << =========================================================================================== >> 
with open('data/DLRAMTwords.txt') as f:
        NumWords = {l.strip('\n') for l in f.readlines()}

with open('data/CurData.txt') as f:
        CurWords = {l.strip('\n') for l in f.readlines()}

# << =========================================================================================== >> 
# <<                                         DEFINITIONS                                         >> 
# << =========================================================================================== >> 

def cleanDoc(doc):
    cleaned = doc.replace('\n', ' ')
    cleaned = cleaned.replace('. ', ' <PHI> ')
    cleaned = cleaned.replace(', ', ' , ')
    return cleaned

#######  get DLRAMT  METHODS ###############
def duplicates(lst, item):
    return [i for i, x in enumerate(lst) if x == item]


def is_num(value):
    value = value.replace(',', '')
    value = value.replace('.', '')
    is_num = value.isdecimal()
    if is_num:
        return 1
    return 0


def is_NUMB(value):
    # NUM_Values = ['one', 'two', 'three', 'four',
    #               'eight', 'nine', 'mln', 'billion']
    if value.lower() in NumWords:
        return 1
    return 0


def is_CUR(value):
    if value.lower() in CurWords:
        return 1
    return 0


def is_WORD(value):
    WORD_Values = ['undisclosed', 'undisclosed', 'withheld']
    if value.lower() in WORD_Values:
        return 1
    return 0


def is_WORD_WORD(value):
    WORD_WORD_Values = ['not disclosed', 'not released',
                        'undisclosed sum', 'undisclosed terms']
    if value.lower() in WORD_WORD_Values:
        return 1
    return 0


def getDlramt(nlpdoc):
    doc = nlpdoc.text

    doc = cleanDoc(doc)
    
    wordByWordDoc = doc.split()
    abstractedWordDoc = wordByWordDoc.copy()
    returnSTR = None
    for x in range(len(wordByWordDoc)):
        if is_num(wordByWordDoc[x]):
            abstractedWordDoc[x] = '<num>'
        if is_NUMB(wordByWordDoc[x]):
            abstractedWordDoc[x] = '<NUMB>'
        if is_CUR(wordByWordDoc[x]):
            abstractedWordDoc[x] = '<CUR>'
        if is_WORD(wordByWordDoc[x]):
            abstractedWordDoc[x] = '<WORD>'
        if x < len(wordByWordDoc)-1:
            val = wordByWordDoc[x]+' '+wordByWordDoc[x+1]
            # print(val)
            if is_WORD_WORD(val):
                abstractedWordDoc[x] = '<WORD_WORD>'
                abstractedWordDoc[x+1] = '<WORD_WORD>'

        # check NUMB patterns
        if '<NUMB>' in abstractedWordDoc:
            # check num NUMB CUR
            indexes = duplicates(abstractedWordDoc, '<NUMB>')
            for i in indexes:
                # check NUMB NUMB CUR
                if abstractedWordDoc[i+1] == '<NUMB>' and abstractedWordDoc[i+2] == '<CUR>':
                    returnSTR = wordByWordDoc[i]+' ' + \
                        wordByWordDoc[i+1]+' '+wordByWordDoc[i+2]
                # check NUMB CUR
                if abstractedWordDoc[i+1] == '<CUR>':
                    returnSTR = wordByWordDoc[i]+' '+wordByWordDoc[i+1]
        # check num patterns
        if '<num>' in abstractedWordDoc:
            # check num NUMB CUR
            indexes = duplicates(abstractedWordDoc, '<num>')
            for i in indexes:
                if i+2<=len(abstractedWordDoc):               
                    # check num NUMB CUR
                    if abstractedWordDoc[i+1] == '<NUMB>' and abstractedWordDoc[i+2] == '<CUR>':
                        returnSTR = wordByWordDoc[i]+' ' + \
                            wordByWordDoc[i+1]+' '+wordByWordDoc[i+2]
                    # check num CUR
                    if abstractedWordDoc[i+1] == '<CUR>':
                        returnSTR = wordByWordDoc[i]+' '+wordByWordDoc[i+1]

        # check WORD patterns
        if '<WORD>' in abstractedWordDoc:
            # check num NUMB CUR
            indexes = duplicates(abstractedWordDoc, '<WORD>')
            for i in indexes:
                returnSTR = wordByWordDoc[i]
        # check WORD_WORD patterns
        if '<WORD_WORD>' in abstractedWordDoc:
            # check num NUMB CUR
            indexes = duplicates(abstractedWordDoc, '<WORD_WORD>')
            for i in indexes:
                returnSTR = wordByWordDoc[i-1]+' '+wordByWordDoc[i]
    # print(abstractedWordDoc)
    return returnSTR


#######  End DLRAMT METHODS ##################