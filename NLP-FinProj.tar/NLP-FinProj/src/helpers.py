#! /bin/python3.8

#* UofU Fa21 cs5340/cs6340
#*  Final Project - Cooperate Acquisition Info Extraction
#* Authors:
#*   - Andrew Osterhout (u1317172)
#*   - JT Herrmann (u0259542)

# << =========================================================================================== >> 
# <<                                           IMPORTS                                           >> 
# << =========================================================================================== >> 

import re
import spacy
from spacy.tokens import Doc, Span
from typing import Union as Un, Dict, Tuple

from src.GLOBALS import ANS_LABELS
Lang = spacy.language.Language


# << =========================================================================================== >> 
# <<                                    GLOBALS AND CONSTANTS                                    >> 
# << =========================================================================================== >> 

# class Answer:
#     def __init__(self, value:Un[Span,str,list,None]=None) -> None:
#         self.__value:str = '---'
#         if type(value) is Span:
#             self.__value:str = ""
# #? END class Answer



# << =========================================================================================== >> 
# <<                                         DEFINITIONS                                         >> 
# << =========================================================================================== >> 


def process_file(file:str, NLP:Lang) -> Doc:
    """
    Simple helper function that given a file path will extract, clean then process 
     it's contents into a spacy `Doc` object for use in the information extraction task at hand.
    (It is super simple just a mask to other hepers to avoid recreating `Lang` models) 

    ARGS:
        `file` (`str`): The file path to the document that needs to be processed.
        `NLP` (`Lang`): The spacy `Lang`/`Language` model object used to generate
            a processed spacy `Doc` for use in extraction tasks.

    RETURNS:
        (Type: `Doc`): The processed document produced by the `Lang` from the file specified by `file`.
        
    AUTHORS:
        Andrew Osterhout (u1317172)
        JT Herrmann (u0259542)
    """
    return NLP(getText(file))
#? END def process_file()


def cleanDoc(doc):
    """Do basic set up for parsing the document.
    - AUTHOR: JT Herrmann (u0259542)"""
    cleaned = doc.replace('\n', ' ')
    cleaned = cleaned.replace('. ', ' <PHI> ')
    cleaned = cleaned.replace(', ', ' , ')
    return cleaned
#? END def cleandoc()


def getText(file) -> str:
    """
    Simple helper function to read the contents of a file and return it as a string.
    
    ARGS:
      `file` (`str`): the file path to the file to read.
    
    RETURNS:
      The contents of the file as one long string.
      
    AUTHORS: 
      JT Herrmann (u0259542)
      Andrew Osterhout (u1317172)
    """
    with open(file, 'r') as text:
        doc = clean_text(text.read())
    return doc
#? END def getText()


def format_answer(value:Un[Span,str,list,None]=None) -> str:
    if value is None:
        return '---'
    v_t = type(value)
    # if v_t = int:
    #     return str(value)
    if v_t == Span:
        return '"'+value.text+'"'
    elif v_t == str:
        return '"'+value+'"'
    elif v_t == list:
        ans = ""
        for v in value[1:]:
            ans += format_answer(v) + ' / '
        return ans + format_answer(value[0])
#? END def format_answer()


def write_answers(outputFileName:str, answers:Dict[str,Un[Span,str,list,None]]) -> None:
    """
    Helper FUnction to write the results of a ... to the standard format used in the answer files.
    
    ARGS:
      `outputFileName` (`str`): The file path to write the contents too.
      `ansers` (`Dict[str,Un[Span,str]]`): 
    
    RETURNS: `None`
    
    AUTHORS:
      JT Herrmann (u0259542)
      Andrew Osterhout (u1317172)
    """
    with open(outputFileName, 'a') as temp:
        for label in ANS_LABELS:
            out = answers["TEXT"] if label == "TEXT" else format_answer(answers[label])
            # print(out)
            temp.write(f'{label}: {out}\n')
        # print('')                 # could be usefull for progress log 
        temp.write('\n')
#? END def writeFile
        

def clean_text(content:str) -> str:
    """Clean up the sentences & get rid of unessisary whitespace"""
    # normalize line spacing
    content = re.sub("\r?\n", ' ', content)
    # remove all extra whitespace
    content = re.sub(r"\s+", ' ', content)
    content = re.sub(r"^\s+", '', content)
    # remove the "Reuter"'s tag at the end of the sentence
    content = re.sub(r"\s*[Rr][Ee][Uu][Tt][Ee][Rr][Ss]?\s*$", '', content)
    # tokenize sentences sentences & split [return]
    return content
#? END clean_text()


def GenDict(ids:list, values:list) -> dict:
    gdict:dict = dict()
    for id,val in zip(ids,values):
        gdict.update({id:val})
    return gdict
#? END def GenDict()


def clean_ans(content:str) -> str:
    "Modify contents so that the ans files are valid yaml for easy reading in"
    content = re.sub(r'("[^"]+" */ *"[^"]+")', r"'\1'", content)
    return content
#? END clean_ans()


def get_NP_from_root(r_loc:int, doc:Doc) -> Span:
    "produce a `Span` from the `doc` that is the Noun-Phrase from the spacy document and the token location of the root of the NP."
    # fast way if the NP ends up in/next-to an entity of appropriate type
    for ent in doc[r_loc-1:r_loc+1].ents: 
        # if tok.ent_type_ in ["ORG",'PERSON','PRODUCT']:   # this isn't useful for general use (save it for deciders)
        if ent.start_char >= doc[r_loc].idx > ent.end_char:
            return ent
    # slow/lazy way if we hav eto manually figure all of this shit out
    start = r_loc
    for i in range(r_loc-1,-1,-1):
        tok = doc[i]
        if tok.dep_ in ["compound", "conj"]: # conj might be more trouble than it's worth.
            start = i
        # elif tok.dep_ in ["amod"]: # deal with issues where compound names are involved
        #     start = i-2
        else:   # noting left worth considering.
            break
    return doc[start:r_loc+1]
#? END def get_NP_from_root()



# << =========================================================================================== >> 
# <<                                       EXECUTE [SETUP]                                       >> 
# << =========================================================================================== >> 

def Setup() -> None:
    """Put anything you want to run when importing anything from this file here"""
    pass
#? END Setup()



# << =========================================================================================== >> 
# <<                                       EXECUTE [MAIN]                                        >> 
# << =========================================================================================== >> 

def Main() -> None:
    """Put any code you want to execute when running this file."""
    pass
#? END Main()


if __name__=="__main__":
    Main()
else:
    Setup()
