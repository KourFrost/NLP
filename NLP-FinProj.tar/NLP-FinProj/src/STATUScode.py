#! /bin/python3.8

#* UofU Fa21 cs5340/cs6340
#*  Final Project - Cooperate Acquisition Info Extraction
#* Authors:
#*   - Andrew Osterhout (u1317172)
#*   - JT Herrmann (u0259542)


# Add items you want to import with `from GLOBALS import *` to this `__all__` list

# << =========================================================================================== >> 
# <<                                           IMPORTS                                           >> 
# << =========================================================================================== >> 


# << =========================================================================================== >> 
# <<                                     GLOBALS & CONSTANTS                                     >> 
# << =========================================================================================== >> 


# << =========================================================================================== >> 
# <<                                         DEFINITIONS                                         >> 
# << =========================================================================================== >> 

def determinStatus(list):
    largest = ''
    for item in list:
        if len(item)> len(largest):
            largest = item
    return largest

def getSTATUS(doc):
    returnSTR = None
    with open('data/knownStatus.txt') as f:
        phrases = {l.strip('\n') for l in f.readlines()}
    validPhrases= []
    for phrase in phrases:
        if phrase in doc:
            validPhrases.append(phrase)

    if len(validPhrases)>0:
        returnSTR = determinStatus(validPhrases)

    return returnSTR