#! /bin/python3.8

#* UofU Fa21 cs5340/cs6340
#*  Final Project - Cooperate Acquisition Info Extraction
#* Author: Andrew Osterhout (u1317172)

# << =========================================================================================== >> 
# <<                                           IMPORTS                                           >> 
# << =========================================================================================== >> 

# << ====================================== Spacy Imports ====================================== >> 
from os import error
import spacy as sp
from spacy.matcher import Matcher, DependencyMatcher
from spacy.tokens import Doc, Span

# << ====================================== Util Imports ======================================= >> 
# import sys.path
from typing import List, Set, Tuple, Union as Un, Dict


# << ============================== Our Helper Functions Imports =============================== >> 
from .helpers import get_NP_from_root


# << =========================================================================================== >> 
# <<                                    BRING IN MY PATTERNS                                     >> 
# << =========================================================================================== >> 
# sys.path += ["../model/"]
from .model.pat_seller import SELLER_DEP_PATTERNS as SEL_PATS, SELLER_TARGET_RIGHT_IDS as SEL_T_IDS
from .model.pat_purchaser import PURCHASER_DEP_PATTERNS as PUR_PATS, PURCHASER_TARGET_RIGHT_IDS as PUR_T_IDS
from .model.pat_acquired import ACQUIRED_DEP_PATTERNS as ACQ_PATS, ACQUIRED_TARGET_RIGHT_IDS as ACQ_T_IDS


# << =========================================================================================== >> 
# <<                                        MY INTERFACE                                         >> 
# << =========================================================================================== >> 

def andrews_stuff(doc:Doc, answers:Dict[str,Un[Span,List[Span]]]) -> None:
    """
    This is my interface for extracting my parts of the information.
    Namely: `ACQUIRED`, `SELLER`, & `PURCHASER`.

    Args:
        `doc` (`Doc`): a Spacy `Doc` of the document to extract the data from.

    Returns:
        `Dict[str,Span]`: A dictionary with the answers to the following keys: `"ACQUIRED"`, `"SELLER"`, & `"PURCHASER"`.
        All values are of the `Span` type, but may be `None` if the answer could not be extracted.
    """
    # - Set up results dict ------------------- 
    answers.update({'ACQUIRED': None,
                    'SELLER': None,
                    'PURCHASER': None})
    matcher = DependencyMatcher(doc.vocab)
    # - get ACQUIRED data ---------------------- 
    # opts = set()
    # for pat in ACQ_PATS:
    #     matcher.add("ACQUIRED", [pat])
    #     opts |= info_extract(doc, matcher, ACQ_T_IDS, pat)
    #     matcher.remove("ACQUIRED")
    # answers['ACQUIRED'] = choose_best(opts, doc)
    # - get SELLER data ------------------------ 
    opts = set()
    for pat in SEL_PATS:
        matcher.add("SELLER", [pat])
        opts |= info_extract(doc, matcher, SEL_T_IDS, pat)
        matcher.remove("SELLER")
    answers['SELLER'] = choose_best(opts, doc)
    # - get PURCHASER data ---------------------- 
    opts = set()
    for pat in PUR_PATS:
        matcher.add("PURCHASER", [pat])
        opts |= info_extract(doc, matcher, PUR_T_IDS, pat)
        matcher.remove("PURCHASER")
    answers['PURCHASER'] = choose_best(opts, doc)
    # - Return results ------------------------- 
    return answers
#? END def andrews_stuff()


# << =========================================================================================== >> 
# <<                                   GENERAL EXTRACTOR CODE                                    >> 
# << =========================================================================================== >> 

def info_extract(doc:Doc, matcher:DependencyMatcher, res_ids:Set[str], pat:List[dict]) -> Set[int]:
    """
    This algorithm just applies the patterns and returns the result.
    Pretty straight forward. 
    The most unique thing is that it will extend to grab an entire NP if the resulting part is just the root of a NP.

    Args:
        `doc` (`Doc`): The spacy Doc object
        `matcher` (`DependencyMatcher`): The matcher object to perform the matching with.
        `res_ids` (`List[str]`): the `"RIGHT_ID"` of the token in the matcher pattern that is the root of the NP of the info we seek.

    Returns:
        `Set[int]`: the token location of possible answers for the 
    """
    opts = set()
    matches:List[Tuple[int,List[int]]] = matcher(doc)
    for j in range(len(matches)):
        mid, tids = matches[j]
        for i in range(len(tids)):
            if pat[i]["RIGHT_ID"] in res_ids:
                opts.add(tids[i])
    return opts
#?END def info_extract()


def choose_best(opts:Set[int], doc:Doc) -> Span:
    """
    Given a set of possible token loc in `doc` (from `opts`), 
    decide what token is the root of the best answer.
    Then return the resulting NP string.
    
    This decision is made by trying to identify the anticendent of pronouns, &
    gathering the total nounphrases.
    
    _**NOTE:** Any filtering based upon passive voice and other sentence structure patterns should be done_
    _in the pattern not here._

    Args:
        `opts` (`Set[int]`): the set of token loc in `doc` for consideration
        `doc` (`Doc`): the doc we are currently workign with.

    Returns:
        `Span`: the resulting NP of the best option as a `Span` from the `doc`.
        (may be `None` if there was no useful match)
    """
    # _opts = [get_NP_from_root(tid,doc) for tid in opts]
    best:Span = None
    for tid in opts:
        # - detractors ---- 
        if doc[tid].pos_ in ["PRP", "PRP$", "WP", "WP$"]: # skip pronouns (maybe try ent link but that is complicated)
            continue
        # - neutrals ---- 
        opt = get_NP_from_root(tid, doc)
        if best is None:
            best = opt
            continue
        # - attractors ---- 
        if best.text in opt.text and opt.text != best.text: # if one is just a longer format name of the other (little blind)
            best = opt
        if len(opt.ents) == 0:
            continue
        elif len(opt.ents) == 1:
            ent_t = opt.ents[0].ent_id_
            if len(best.ents) == 0:
                best = opt
                continue
            elif len(best.ents) == 1:
                b_ent_t = best.ents[0].ent_id_
                if ent_t == "ORG":
                    if b_ent_t not in "ORG":
                        best = opt # swap for better.
                elif ent_t == "PERSON":
                    if b_ent_t not in ["ORG", "PERSON"]:
                        best = opt
                elif ent_t == "PRODUCT":
                    if b_ent_t not in ["ORG", "PERSON", "PRODUCT"]:
                        best = opt
                elif ent_t == "WORK_OF_ART":
                    if b_ent_t not in ["ORG", "PERSON", "PRODUCT", "WORK_OF_ART"]:
                        best = opt
            else: # ERROR the NP extractor grabbed multiple NP's !!!
                continue
                # msg = f"ERROR more than one NP in NP!! [andrew.best_choice/best]\n\tbest: '{str(best)}'"
                # raise error(msg)
        else: # ERROR the NP extractor grabbed multiple NP's !!!
            continue
            # msg = f"ERROR more than one NP in NP!! [andrew.best_choice/opt]\n\topt: '{str(opt)}'"
            # raise error(msg)
    return best
#? END def choose_best()


