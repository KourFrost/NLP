#! /bin/python3.8

#* UofU Fa21 cs5340/cs6340
#*  Final Project - Cooperate Acquisition Info Extraction
#* Authors:
#*   - Andrew Osterhout (u1317172)
#*   - JT Herrmann (u0259542)


# Add items you want to import with `from GLOBALS import *` to this `__all__` list

# << =========================================================================================== >> 
# <<                                           IMPORTS                                           >> 
# << =========================================================================================== >> 
import random

# << =========================================================================================== >> 
# <<                                     GLOBALS & CONSTANTS                                     >> 
# << =========================================================================================== >> 


# << =========================================================================================== >> 
# <<                                         DEFINITIONS                                         >> 
# << =========================================================================================== >> 

####### get ACQBUS Catagory #############
def determinACQBUS(list):
    return random.choice(list)

def getACQBUS(doc):
    returnSTR = None
    with open('data/knownIndustries.txt') as f:
        Industries = {l.strip('\n') for l in f.readlines()}
    validIndustries= []
    for Industry in Industries:
        if Industry in doc:
            validIndustries.append(Industry)

    if len(validIndustries)>0:
        returnSTR = determinACQBUS(validIndustries)


    return returnSTR