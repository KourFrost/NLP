#! /bin/python3.8

# * UofU Fa21 cs5340/cs6340
# *  Final Project - Cooperate Acquisition Info Extraction
# * Author: Andrew Osterhout (u1317172)

from src.model.words import *

SELLER_DEP_PATTERNS = [
    [  # <subj=SELLER> ... VP('sell')
        {  # VP(sell)
            'RIGHT_ID': "VP('sell')",
            'RIGHT_ATTRS': {
                'POS': "VERB",
                'LEMMA': {'IN': SELL_VERB_WORDS}
            }
        },
        {  # <subj=SELLER>
            'LEFT_ID': "VP('sell')",
            'REL_OP': ">>",
            'RIGHT_ID': "<subj=SELLER>",
            'RIGHT_ATTRS': {
                'DEP': {'IN': ["csubj", "nsubj", "subj"]},
                # 'ENT_TYPE':"ORG"
            }
        }
    ],
    [  # <subj=SELLER> ... VP(parent) ... VP('sell')
        {  # VP(parent)
            'RIGHT_ID': "VP(parent)",
            'RIGHT_ATTRS': {
                'POS': "VERB",
                'DEP': "ROOT"
            }
        },
        {  # <subj=SELLER>
            'LEFT_ID': "VP(parent)",
            'REL_OP': ">>",
            'RIGHT_ID': "<subj=SELLER>",
            'RIGHT_ATTRS': {'DEP': {'IN': ["csubj", "nsubj", "subj"]}}
        },
        {  # VP('sell')
            'LEFT_ID': "VP(parent)",
            'REL_OP': ">>",
            'RIGHT_ID': "VP('sell')",
            'RIGHT_ATTRS': {
                'POS': "VERB",
                'LEMMA': {'IN': SELL_VERB_WORDS}
            },
        }
    ],
    # << ------------------------------------------------------------------------------------------- >> 
    [  # VP('buy') dobj(any) Prep('from') <pobj=SELLER>
        {  # VP('buy')
            'RIGHT_ID': "VP('buy')",
            'RIGHT_ATTRS': {
                'POS': "VERB",
                'LEMMA': {'IN': BUY_VERB_WORDS}
            }
        },
        {  # dobj(any)
            'LEFT_ID': "VP('buy')",
            'REL_OP': ">>",
            'RIGHT_ID': "dobj(any)",
            'RIGHT_ATTRS': {
                'DEP': {'IN': ["dobj"]},
                # 'ENT_TYPE':"ORG"
            }
        },
        {  # Prep('from')
            'LEFT_ID': "dobj(any)",
            'REL_OP': ">",
            'RIGHT_ID': "Prep('from')",
            'RIGHT_ATTRS': {
                'DEP': {'IN': ['prep']},
                'ORTH': {'IN': BUY_FROM_PREP_WORDS}
            }
        },
        {  # <pobj=SELLER>
            'LEFT_ID': "Prep('from')",
            'REL_OP': ">",
            'RIGHT_ID': "<pobj=SELLER>",
            'RIGHT_ATTRS': {
                'DEP': {'IN': ['pobj']}
            }
        },
    ], 
    [  # VP(parent) ... VP('buy') ... dobj(any) Prep('from') <pobj=SELLER>
        {  # VP(parent)
            'RIGHT_ID': "VP(parent)",
            'RIGHT_ATTRS': {
                'POS': "VERB",
                'DEP': "ROOT"
            }
        },
        {  # VP('buy')
            'LEFT_ID': "VP(parent)",
            'REL_OP': ">>",
            'RIGHT_ID': "VP('buy')",
            'RIGHT_ATTRS': {
                'POS': "VERB",
                'LEMMA': {'IN': BUY_VERB_WORDS}
            }
        },
        {  # dobj(any)
            'LEFT_ID': "VP(parent)",
            'REL_OP': ">>",
            'RIGHT_ID': "dobj(any)",
            'RIGHT_ATTRS': {
                'DEP': {'IN': ["dobj"]},
                # 'ENT_TYPE':"ORG"
            }
        },
        {  # Prep('from')
            'LEFT_ID': "dobj(any)",
            'REL_OP': ">",
            'RIGHT_ID': "Prep('from')",
            'RIGHT_ATTRS': {
                'DEP': {'IN': ['prep']},
                'ORTH': {'IN': BUY_FROM_PREP_WORDS}
            }
        },
        {  # <pobj=SELLER>
            'LEFT_ID': "Prep('from')",
            'REL_OP': ">",
            'RIGHT_ID': "<pobj=SELLER>",
            'RIGHT_ATTRS': {
                'DEP': {'IN': ['pobj']}
            }
        },
    ],
    # << ------------------------------------------------------------------------------------------- >> 
    [  # VP('buy') dobj('asset') Prep('of') pobj(any) Prep('from') <pobj=SELLER>
        {  # VP('buy')
            'RIGHT_ID': "VP('buy')",
            'RIGHT_ATTRS': {
                'POS': "VERB",
                'LEMMA': {'IN': BUY_VERB_WORDS}
            }
        },
       {  # dobj(any)
            'LEFT_ID': "VP('buy')",
            'REL_OP': ">",
            'RIGHT_ID': "dobj(any)",
            'RIGHT_ATTRS': {
                'DEP': {'IN': ["dobj"]},
                # 'ENT_TYPE':"ORG"
            }
        },
        {  # Prep('of')
            'LEFT_ID': "dobj(any)",
            'REL_OP': ">",
            'RIGHT_ID': "Prep('of')",
            'RIGHT_ATTRS': {
                'DEP': {'IN': ['prep']},
                'ORTH': {'IN': ASSETS_OF_PREP_WORDS}
            }
        },
        {  # pobj(any)
            'LEFT_ID': "Prep('of')",
            'REL_OP': ">",
            'RIGHT_ID': "pobj(any)",
            'RIGHT_ATTRS': {
                'DEP': {'IN': ["dobj"]},
                # 'ENT_TYPE':"ORG"
            }
        },
        {  # Prep('from')
            'LEFT_ID': "pobj(any)",
            'REL_OP': ">",
            'RIGHT_ID': "Prep('from')",
            'RIGHT_ATTRS': {
                'DEP': {'IN': ['prep']},
                'ORTH': {'IN': BUY_FROM_PREP_WORDS}
            }
        },
        {  # <pobj=SELLER>
            'LEFT_ID': "Prep('from')",
            'REL_OP': ">",
            'RIGHT_ID': "<pobj=SELLER>",
            'RIGHT_ATTRS': {
                'DEP': {'IN': ['pobj']}
            }
        },
    ],
    [  # VP(parent) ... VP('buy') ... dobj('asset') Prep('of') pobj(any) Prep('from') <pobj=SELLER>
        {  # VP(parent)
            'RIGHT_ID': "VP(parent)",
            'RIGHT_ATTRS': {
                'POS': "VERB",
                'DEP': "ROOT"
            }
        },
        {  # VP('buy')
            'LEFT_ID': "VP(parent)",
            'REL_OP': ">>",
            'RIGHT_ID': "VP('buy')",
            'RIGHT_ATTRS': {
                'POS': "VERB",
                'LEMMA': {'IN': BUY_VERB_WORDS}
            }
        },
        {  # dobj(any)
            'LEFT_ID': "VP(parent)",
            'REL_OP': ">",
            'RIGHT_ID': "dobj('asset')",
            'RIGHT_ATTRS': {
                'DEP': {'IN': ["dobj"]},
                'ORTH': {'IN': ASSET_NOUN_WORDS}
                # 'ENT_TYPE':"ORG"
            }
        },
        {  # Prep('of')
            'LEFT_ID': "dobj('asset')",
            'REL_OP': ">",
            'RIGHT_ID': "Prep('of')",
            'RIGHT_ATTRS': {
                'DEP': {'IN': ['prep']},
                'ORTH': {'IN': ASSETS_OF_PREP_WORDS}
            }
        },
        {  # pobj(any)
            'LEFT_ID': "Prep('of')",
            'REL_OP': ">",
            'RIGHT_ID': "pobj(any)",
            'RIGHT_ATTRS': {
                'DEP': {'IN': ["dobj"]},
                # 'ENT_TYPE':"ORG"
            }
        },
        {  # Prep('from')
            'LEFT_ID': "pobj(any)",
            'REL_OP': ">",
            'RIGHT_ID': "Prep('from')",
            'RIGHT_ATTRS': {
                'DEP': {'IN': ['prep']},
                'ORTH': {'IN': BUY_FROM_PREP_WORDS}
            }
        },
        {  # <pobj=SELLER>
            'LEFT_ID': "Prep('from')",
            'REL_OP': ">",
            'RIGHT_ID': "<pobj=SELLER>",
            'RIGHT_ATTRS': {
                'DEP': {'IN': ['pobj']}
            }
        },
    ],
    # [ #
    #     { # dsa
    #       '': ...
    #     }
    # ]
]

SELLER_TARGET_RIGHT_IDS = {
    "<subj=SELLER>",  # <subj=SELLER> ... VP('sell')
    "<subj=SELLER>",  # <subj=SELLER> ... VP(parent) ... VP('sell')
    "<pobj=SELLER>",  # VP('buy') dobj(any) Prep('from') <pobj=SELLER>
    "<pobj=SELLER>", # VP(parent) ... VP('buy') ... dobj(any) Prep('from') <pobj=SELLER>
    "<pobj=SELLER>",  # VP('buy') dobj('asset') Prep('of') pobj(any) Prep('from') <pobj=SELLER>
    "<pobj=SELLER>", # VP(parent) ... VP('buy') ... dobj('asset') Prep('of') pobj(any) Prep('from') <pobj=SELLER>
}

# for the normal matcher
SELLER_PATTERN = [  # !! THIS ISN'T GOING TO WORK
    [  # <subj=SELLER> VP(x)* VP('sell')
        {  # <subj=SELLER>
            'DEP': "compound",
            'ENT_TYPE': "ORG",
            'OP': "*"
        },
        {  # <subj=SELLER>
            'DEP': {'IN': ["nsubj", "csubj"]},
            'ENT_TYPE': "ORG"
        },
        {  # VP(x)
            'DEP': ""
        }
    ]
]
