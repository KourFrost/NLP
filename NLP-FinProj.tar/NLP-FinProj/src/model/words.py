#! /bin/python3.8

#* UofU Fa21 cs5340/cs6340
#*  Final Project - Cooperate Acquisition Info Extraction
#* Author: Andrew Osterhout (u1317172)


# A list of words that can be used in a lemma to represent the concept of selling
SELL_VERB_WORDS = ["sell", "sold", "selling"]
BUY_VERB_WORDS = ["acquire", "acquired", "acquiring", "buy", "bought", "buying", "purchase", "purchased", "purchasing"]
# A list of words that can be used in a lemma to represent the concept of agreeing to something
AGREE_VERB_WORDS = ["agree"]
# a list of words that can be used with a "TEXT" matcher clause to identify prepositions indicating a bridge from sell to the purchaser
SELL_TO_PREP_WORDS = ["to"]
BUY_FROM_PREP_WORDS = ["from"]
ASSETS_OF_PREP_WORDS = ["of", 'in', 'from']

ASSET_NOUN_WORDS = ["asset", "assets", 'stock', 'stocks', 'share', 'shares', 'stake', 'stakes']
