#! /bin/python3.8

#* UofU Fa21 cs5340/cs6340
#*  Final Project - Cooperate Acquisition Info Extraction
#* Author: Andrew Osterhout (u1317172)

from src.model.words import *

PURCHASER_DEP_PATTERNS = [
    [# <subj=PURCHASER> ... VP('buy')
        { # VP(sell)
            'RIGHT_ID': "VP('buy')",
            'RIGHT_ATTRS': {
                'POS': "VERB",
                'LEMMA': {'IN': BUY_VERB_WORDS}
            }
        },
        { # <subj=PURCHASER>
            'LEFT_ID': "VP('buy')",
            'REL_OP': ">>",
            'RIGHT_ID': "<subj=PURCHASER>",
            'RIGHT_ATTRS': {
                'DEP': {'IN': ["csubj","nsubj","subj"]},
                # 'ENT_TYPE':"ORG"
            }
        }
    ],
    [ # <subj=PURCHASER> ... VP(parent) ... VP('buy') 
        { # VP(parent)
            'RIGHT_ID': "VP(parent)",
            'RIGHT_ATTRS': {
                'POS': "VERB",
                'DEP': "ROOT"
            }
        },
        { # <subj=PURCHASER>
            'LEFT_ID': "VP(parent)",
            'REL_OP': ">>",
            'RIGHT_ID': "<subj=PURCHASER>",
            'RIGHT_ATTRS': {'DEP': {'IN': ["csubj","nsubj","subj"]}}
        },
        { # VP('buy')
            'LEFT_ID': "VP(parent)",
            'REL_OP': ">>",
            'RIGHT_ID': "VP('buy')",
            'RIGHT_ATTRS': {
                'POS': "VERB",
                'LEMMA': {'IN': BUY_VERB_WORDS}
            },
        }
    ],
    [ # VP('sell') ... Prep('to') ... <pobj=PURCHASER>
        { # VP('sell')
            'RIGHT_ID': "VP('sell')",
            'RIGHT_ATTRS': {
                'POS': "VERB",
                'LEMMA': {'IN': BUY_VERB_WORDS}
            }
        },
        { # Prep('to')
            'LEFT_ID': "VP('sell')",
            'REL_OP': "<",
            'RIGHT_ID': "Prep('to')",
            'RIGHT_ATTRS': {
                'POS': {'IN': ["IN", "ADP"]},
                'DEP': "prep",
                'ORTH': {'IN': SELL_TO_PREP_WORDS}
            }
        },
        { # <pobj=PURCHASER>
            'LEFT_ID': "Prep('to')",
            'REL_OP': "<",
            'RIGHT_ID': "<pobj=PURCHASER>",
            'RIGHT_ATTRS': {
                'POS': {'IN': ["PROPN", "NOUN", "NN", "NNP", "NNPS", "NNS"]},
                # 'ORTH': {'IN': SELL_TO_PREP_WORDS}
            }
        }
    ],
     [ # VP(parent)...VP('sell')...Prep('to') <pobj=ACQUIRED>
        { # VP(parent)
            'RIGHT_ID': "VP(parent)",
            'RIGHT_ATTRS': {
                # 'POS': "VERB",
                'DEP': "ROOT"
            }
        },
        { # VP('sell')
            'LEFT_ID': "VP(parent)",
            'REL_OP': ">>",
            'RIGHT_ID': "VP('sell')",
            'RIGHT_ATTRS': {
                # 'POS': "VERB",
                'LEMMA': {'IN': BUY_VERB_WORDS}
            },
        },
        { # Prep('to')
            'LEFT_ID': "VP(parent)",
            'REL_OP': "<",
            'RIGHT_ID': "Prep('to')",
            'RIGHT_ATTRS': {
                'POS': {'NOT_IN': ["TO"]},
                'DEP': "prep",
                'ORTH': {'IN': SELL_TO_PREP_WORDS}
            }
        },
        { # <pobj=PURCHASER>
            'LEFT_ID': "Prep('to')",
            'REL_OP': "<",
            'RIGHT_ID': "<pobj=PURCHASER>",
            'RIGHT_ATTRS': {
                'POS': {'IN': ["PROPN", "NOUN", "NN", "NNP", "NNPS", "NNS"]},
                # 'ORTH': {'IN': SELL_TO_PREP_WORDS}
            }
        },
    ]
]

PURCHASER_TARGET_RIGHT_IDS = {
    "<subj=PURCHASER>", # <subj=PURCHASER> ... VP('buy')
    "<subj=PURCHASER>", # <subj=PURCHASER> ... VP(parent) ... VP('buy') 
    "<pobj=PURCHASER>", # VP('sell') ... Prep('to') ... <pobj=PURCHASER>
    "<pobj=PURCHASER>", # VP(parent)...VP('sell')...Prep('to') <pobj=ACQUIRED>
}
