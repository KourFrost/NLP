#! /bin/python3.8

#* UofU Fa21 cs5340/cs6340
#*  Final Project - Cooperate Acquisition Info Extraction
#* Author: Andrew Osterhout (u1317172)

from src.model.words import *

ACQUIRED_DEP_PATTERNS = [
    [ # VP('sell'/'buy')...<dobj=ACQUIRED>
        { # VP('sell')
            'RIGHT_ID': "VP('sell'/'buy')",
            'RIGHT_ATTRS': {
                'POS': "VERB",
                'LEMMA': {'IN': SELL_VERB_WORDS + BUY_VERB_WORDS}
            },
        },
        { # <dobj=ACQUIRED>
            'LEFT_ID': "VP('sell'/'buy')",
            'REL_OP': ">",
            'RIGHT_ID': "<dobj=ACQUIRED>",
            'RIGHT_ATTRS': {
                # 'ENT_TYPE': "ORG",
                'ORTH': {'NOT_IN': ASSET_NOUN_WORDS},
                'DEP': {'IN': ["npadvmod", "dobj"]}
            }
        }
    ],
    [ # VP(parent)...VP('sell'/'buy')...<npadvmod=ACQUIRED>
        { # VP(parent)
            'RIGHT_ID': "VP(parent)",
            'RIGHT_ATTRS': {
                'POS': "VERB",
                'DEP': "ROOT"
            }
        },
        { # VP('sell')
            'LEFT_ID': "VP(parent)",
            'REL_OP': ">>",
            'RIGHT_ID': "VP('sell'/'buy')",
            'RIGHT_ATTRS': {
                'POS': "VERB",
                'LEMMA': {'IN': SELL_VERB_WORDS + BUY_VERB_WORDS}
            },
        },
        { # <npadvmod=ACQUIRED>
            'LEFT_ID': "VP(parent)",
            'REL_OP': ">",
            'RIGHT_ID': "<npadvmod=ACQUIRED>",
            'RIGHT_ATTRS': {
                # 'ENT_TYPE': "ORG",
                'ORTH': {'NOT_IN': ASSET_NOUN_WORDS},
                'DEP': {'IN': ["npadvmod", "dobj"]}
            }
        }
    ],
    [ # VP('sell'/'buy') dobj('asset') Prep('in') <pobj=ACQUIRED>
        { # VP('sell')
            'RIGHT_ID': "VP('sell'/'buy')",
            'RIGHT_ATTRS': {
                'POS': "VERB",
                'LEMMA': {'IN': SELL_VERB_WORDS + BUY_VERB_WORDS}
            },
        },
        { # dobj('asset')
            'LEFT_ID': "VP('sell'/'buy')",
            'REL_OP': ">",
            'RIGHT_ID': "dobj('asset')",
            'RIGHT_ATTRS': {
                'ORTH': {'IN': ASSET_NOUN_WORDS},
                'DEP': {'IN': ["dobj"]}
            }
        },
        { # Prep('in')
            'LEFT_ID': "dobj('asset')",
            'REL_OP': ">",
            'RIGHT_ID': "Prep('in')",
            'RIGHT_ATTRS': {
                'ORTH': {'IN': ASSETS_OF_PREP_WORDS},
                # 'POS': {'IN': ["PREP", "IN"]},
            }
        },
        { # <pobj=ACQUIRED>
            'LEFT_ID': "Prep('in')",
            'REL_OP': ">",
            'RIGHT_ID': "<pobj=ACQUIRED>",
            'RIGHT_ATTRS': {
                # 'ENT_TYPE': "ORG",
                'ORTH': {'NOT_IN': ASSET_NOUN_WORDS},
                'DEP': {'IN': ["npadvmod", "dobj"]}
            }
        }
    ],
    [ # VP(parent)...VP('sell'/'buy')...dobj('asset') Prep('in') <pobj=ACQUIRED>
        { # VP(parent)
            'RIGHT_ID': "VP(parent)",
            'RIGHT_ATTRS': {
                'POS': "VERB",
                'DEP': "ROOT"
            }
        },
        { # VP('sell')
            'LEFT_ID': "VP(parent)",
            'REL_OP': ">>",
            'RIGHT_ID': "VP('sell'/'buy')",
            'RIGHT_ATTRS': {
                'POS': "VERB",
                'LEMMA': {'IN': SELL_VERB_WORDS + BUY_VERB_WORDS}
            },
        },
        { # dobj('asset')
            'LEFT_ID': "VP(parent)",
            'REL_OP': ">",
            'RIGHT_ID': "dobj('asset')",
            'RIGHT_ATTRS': {
                'ORTH': {'IN': ASSET_NOUN_WORDS},
                'DEP': {'IN': ["dobj"]}
            }
        },
        { # Prep('in')
            'LEFT_ID': "dobj('asset')",
            'REL_OP': ">",
            'RIGHT_ID': "Prep('in')",
            'RIGHT_ATTRS': {
                'ORTH': {'IN': ASSETS_OF_PREP_WORDS},
                # 'POS': {'IN': ["PREP", "IN"]},
            }
        },
        { # <pobj=ACQUIRED>
            'LEFT_ID': "Prep('in')",
            'REL_OP': ">",
            'RIGHT_ID': "<pobj=ACQUIRED>",
            'RIGHT_ATTRS': {
                # 'ENT_TYPE': "ORG",
                'ORTH': {'NOT_IN': ASSET_NOUN_WORDS},
                'DEP': {'IN': ["npadvmod", "dobj"]}
            }
        }
    ]
]


ACQUIRED_TARGET_RIGHT_IDS = {
    "<dobj=ACQUIRED>", # VP('sell'/'buy')...<dobj=ACQUIRED> 
    "<npadvmod=ACQUIRED>", # VP(parent)...VP('sell'/'buy')...<npadvmod=ACQUIRED>
    "<pobj=ACQUIRED>", # VP('sell'/'buy') dobj('asset') Prep('in') <pobj=ACQUIRED>
    "<pobj=ACQUIRED>", # VP(parent)...VP('sell'/'buy')...dobj('asset') Prep('in') <pobj=ACQUIRED>
}
