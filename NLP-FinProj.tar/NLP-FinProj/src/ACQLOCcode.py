#! /bin/python3.8

#* UofU Fa21 cs5340/cs6340
#*  Final Project - Cooperate Acquisition Info Extraction
#* Authors:
#*   - Andrew Osterhout (u1317172)
#*   - JT Herrmann (u0259542)


# Add items you want to import with `from GLOBALS import *` to this `__all__` list

# << =========================================================================================== >> 
# <<                                           IMPORTS                                           >> 
# << =========================================================================================== >> 
import random




# << =========================================================================================== >> 
# <<                                     GLOBALS & CONSTANTS                                     >> 
# << =========================================================================================== >> 


# << =========================================================================================== >> 
# <<                                         DEFINITIONS                                         >> 
# << =========================================================================================== >> 



####### get LOC METHODS #####################
def determinLOC(list):
    return random.choice(list)

def getLOC(nlpdoc):

    returnSTR = None
    LocList= []
    for ent in nlpdoc.ents:
        if ent.label_ in ('NORP', 'GPE') :
           LocList.append(ent.text)

    if len(LocList)>0:
        returnSTR = determinLOC(LocList)

    return returnSTR
