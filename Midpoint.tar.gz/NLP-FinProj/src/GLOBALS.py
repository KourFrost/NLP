#! /bin/python3.8

#* UofU Fa21 cs5340/cs6340
#*  Final Project - Cooperate Acquisition Info Extraction
#* Authors:
#*   - Andrew Osterhout (u1317172)
#*   - JT ...


# Add items you want to import with `from GLOBALS import *` to this `__all__` list
__all__ = ['DATA_COL_LABLES', 'VEC_COL_LABELS']

# << =========================================================================================== >> 
# <<                                           IMPORTS                                           >> 
# << =========================================================================================== >> 



# << =========================================================================================== >> 
# <<                                     GLOBALS & CONSTANTS                                     >> 
# << =========================================================================================== >> 
DATA_COL_LABELS = ['id', 'content', 'nlp', 'vecs']
VEC_COL_LABELS = ['#', 'id', 
                  'Word-1','Word', 'Word+1', 
                  'POS-1', 'POS', 'POS+1',
                  'NERT-1', 'NERT', 'NERT+1', 'NERT-1=?', 'NERT+1=?',
                  'NERID-1', 'NERID', 'NERID+1', 'NERID-1=?', 'NERID+1=?',
                  'Dep', 'Dep-P', 'Dep-P-POS',
                  'Num?', 'Denom?', 'Loc?', 'Org?',
                  'ACQUIRED?', 'ACQBUS?', 'ACQLOC?', 'DLRAMT?', 'PURCHASER?', 'SELLER?', 'STATUS?'
                  ]

