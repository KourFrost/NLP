#! /bin/python3.8

#* UofU Fa21 cs5340/cs6340
#*  Final Project - Cooperate Acquisition Info Extraction
#* Authors:
#*   - Andrew Osterhout (u1317172)
#*   - JT ...

# << =========================================================================================== >> 
# <<                                           IMPORTS                                           >> 
# << =========================================================================================== >> 

import re


# << =========================================================================================== >> 
# <<                                    GLOBALS AND CONSTANTS                                    >> 
# << =========================================================================================== >> 





# << =========================================================================================== >> 
# <<                                         DEFINITIONS                                         >> 
# << =========================================================================================== >> 

def clean_text(content:str) -> str:
    """Clean up the sentences & get rid of unessisary whitespace"""
    # normalize line spacing
    content = re.sub("\r?\n", ' ', content)
    # remove all extra whitespace
    content = re.sub(r"\s+", ' ', content)
    content = re.sub(r"^\s+", '', content)
    # remove the "Reuter"'s tag at the end of the sentence
    content = re.sub(r"\s*[Rr][Ee][Uu][Tt][Ee][Rr][Ss]?\s*$", '', content)
    # tokenize sentences sentences & split [return]
    return content
#? END clean_text()



# << =========================================================================================== >> 
# <<                                       EXECUTE [SETUP]                                       >> 
# << =========================================================================================== >> 

def Setup() -> None:
    """Put anything you want to run when importing anything from this file here"""
    pass
#? END Setup()



# << =========================================================================================== >> 
# <<                                       EXECUTE [MAIN]                                        >> 
# << =========================================================================================== >> 

def Main() -> None:
    """Put any code you want to execute when running this file."""
    pass
#? END Main()


if __name__=="__main__":
    Main()
else:
    Setup()
