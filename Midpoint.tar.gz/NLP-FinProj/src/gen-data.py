#! /bin/python3.8

#* UofU Fa21 cs5340/cs6340
#*  Final Project - Cooperate Acquisition Info Extraction
#* Authors:
#*   - Andrew Osterhout (u1317172)
#*   - JT ...


# << =========================================================================================== >> 
# <<                                           IMPORTS                                           >> 
# << =========================================================================================== >> 

# << ====================================== Util Imports ======================================= >> 
import pandas as pd
from csv import DictWriter
from helpers import clean_text

# << ======================================= NLP Imports ======================================= >> 
import spacy
from spacy.language import Language
# from nltk.tokenize import sent_tokenize # unessisary just use `.sents` on the doc post nlp/langmodel 


# << =========================================================================================== >> 
# <<                                     GLOBALS & CONSTANTS                                     >> 
# << =========================================================================================== >> 
NLP = spacy.load('en_core_web_sm')
from GLOBALS import *



# << =========================================================================================== >> 
# <<                                   DEFINE HELPER FUNCTIONS                                   >> 
# << =========================================================================================== >> 

def import_data(files, nlp:Language) -> pd.DataFrame:
    """Produce the dataframes to work with"""
    df = pd.DataFrame(columns=DATA_COL_LABELS)
    for file_p,i in zip(files,range(len(files))):
        df.loc[i,'id'] = Path(file_p).stem
        with open(file_p, 'r') as file:
            cont = clean_text(file.read())
            df.loc[i,'content'] = cont
            df.loc[i,'nlp'] = nlp(cont)
    return df
#? END import_data()




# << =========================================================================================== >> 
# <<                                       EXECUTE [MAIN]                                        >> 
# << =========================================================================================== >> 

def Main() -> None:
    """Put any code you want to execute when running this file."""
    pass
#? END Main()


if __name__ == "__main__":
    Main()
