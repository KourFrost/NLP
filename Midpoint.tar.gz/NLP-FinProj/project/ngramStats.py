import sys

from os import walk
import re
def replace(old, new, str, caseinsentive = False):
    if caseinsentive:
        return str.replace(old, new)
    else:
        return re.sub(re.escape(old), new, str, flags=re.IGNORECASE)

def getKeys(file):
    file1 = open(file, 'r')
    Lines = file1.readlines()
    
    output = []
    for line in Lines:
        if len(line)> 3:
            info = line.split(':', 1)
            # print(info)
            hasValue = info[1] != ' ---\n'
            if hasValue:
                value = info[1].replace(' "','')
                value = value.replace('"\n','')
                key = '<'+info[0]+'>'
                output.append([key, value])
    return output
pathKey='development-anskeys'

filenames = next(walk(pathKey), (None, None, []))[2]  # [] if no file

# print(len(filenames))

pathText='development-docs'
printValue = False
preAquired = {}
postAquried = {}
for file in filenames:
    filePath = pathKey+'/'+file
    keys = getKeys(filePath)

    
    #get text
    docPath = pathText+'/'+file[:-4] 
    doc = open(docPath, 'r').read()
    doc =doc.replace('\n', ' ')
    # doc =doc.replace('. ', '. <PHI> ')
    doc =doc.replace('    ', ' ')

    keyReplacedDoc = doc
    skipText = False
    textid=0
    for key in keys:
        if not skipText:
            textid= key[1]
        if skipText:
            
            
            value = key[1].replace('"','')
            value = key[1].replace('\n','')
            keyValues = value.split('/')
            ngramDoc = doc
            ngramDoc = ngramDoc.replace('  ',' ')
            for val in keyValues:
                ngramDoc = replace(val, key[0]+' ', ngramDoc)
                keyReplacedDoc = replace(val, key[0]+' ', keyReplacedDoc)


            # print(ngramDoc)
            
            splitNgramDoc = ngramDoc.split()
            if key[0] not in splitNgramDoc:
                print('')
                print(textid)
                print(key[0])
                print(keyValues)
                print(ngramDoc)
            else:
                index = splitNgramDoc.index(key[0])
                

                if key[0] == '<ACQUIRED>':
                    prevWord1 = splitNgramDoc[index-1]
                    prevWord2 = splitNgramDoc[index-2]
                    postWord1 = splitNgramDoc[index+1]
                    postWord2 = splitNgramDoc[index+2]
                    if (prevWord1 in preAquired.keys()):
                        preAquired[prevWord1] = preAquired[prevWord1]+1
                    else:
                        preAquired[prevWord1] = 1
                    word2gram =  prevWord2+' '+ prevWord1 
                    if (word2gram in preAquired.keys()):
                        preAquired[word2gram] = preAquired[word2gram]+1
                    else:
                        preAquired[word2gram] = 1

                    #post wordList
                    if (postWord1 in postAquried.keys()):
                        postAquried[postWord1] = postAquried[postWord1]+1
                    else:
                        postAquried[prevWord1] = 1
                    word2gram =  postWord2+' '+ postWord1 
                    if (word2gram in postAquried.keys()):
                        postAquried[word2gram] = postAquried[word2gram]+1
                    else:
                        postAquried[word2gram] = 1
        skipText=True
    # if printValue:
    #     print('')
    #     print(keys)
    # #     print('')
    # #     print(doc)
    # #     print('')
    #     print(keyReplacedDoc)
    #     print('')
    # printValue = False
print(preAquired)
print(postAquried)
    # print(keys)