import sys
import os
import numpy as np

def output(name, dict):
    print(name)
    print('SIZE:', len(dict))
    key = max(dict, key=dict.get)
    print('MAX:',key, dict[key])
    print('MEAN:', np.mean(list(dict.values())))
    print('')

def addValue(key, dic):
    if key in dic:
        dic[key] = dic[key] + 1
    else:
        dic[key] = 1
    return dic

ACQ = {}
ACQBUS={}
ACQLOC={}
DLRAMT={}
PURCHASER={}
SELLER={}
STATUS={}

for filename in os.listdir("development-anskeys"):
    with open(os.path.join("development-anskeys", filename), 'r') as f:
        text = f.read()
        line_separated_text = text.splitlines()

        lineSkip = True
        for line in line_separated_text:
            if lineSkip:
                lineSkip = False
            else:
                item_seperated_text = line.split()
                entrySkip = True  
                if len(item_seperated_text)>0:
                    dict_value = item_seperated_text[0]
                    for entry in item_seperated_text:
                        if entrySkip:
                            entrySkip = False
                        else:
                            entry = entry.replace('"', '')
                            if entry != '---':
                                if dict_value == "ACQUIRED:": 
                                    ACQ = addValue(entry, ACQ)
                                if dict_value == "ACQBUS:": 
                                    ACQBUS = addValue(entry, ACQBUS)
                                if dict_value == "ACQLOC:": 
                                    ACQLOC = addValue(entry, ACQLOC)
                                if dict_value == "DLRAMT:": 
                                    DLRAMT = addValue(entry, DLRAMT)
                                if dict_value == "PURCHASER:": 
                                    PURCHASER = addValue(entry, PURCHASER)
                                if dict_value == "SELLER:": 
                                    SELLER = addValue(entry, SELLER)
                                if dict_value == "STATUS:": 
                                    STATUS = addValue(entry, STATUS)

output('ACQUIRED', ACQ)
output('ACQBUS', ACQBUS)
output('ACQLOC', ACQLOC)
output('DLRAMT', DLRAMT)
output('PURCHASER', PURCHASER)
output('SELLER', SELLER)
output('STATUS', STATUS)

# for key, value in sorted(DLRAMT.items(), key=lambda item: item[1]):
#     print("%s: %s" % (key, DLRAMT[key]))

# print()
# print('********')
# print()


# for key, value in sorted(STATUS.items(), key=lambda item: item[1]):
#     print("%s: %s" % (key, STATUS[key]))