# NLP-FinProj
Final Project for [UofU Fa21 CS 5340 - Natural Language Processing]. Where we create an Information Extraction System for cooperate acquisition information. 

(a) A list of all external resources (libraries, software, knowledge bases, or other tools) that your system uses, along with a URL or citation for each one that tells us what it is and where it came from.

for exract.py 
    sys for getting arguments
    

(b) A time estimate of how long your system takes to process ONE document. (This will give the TAs an estimate of how long they should expect to wait to see the results.)

3 seconds

(c) For 2-person teams, please list which parts of the system each team member substantially contributed to.

Andrew- spacy integration, pipeline architecture, file organization
JT- I/O, pattern extractions

(d) Please explain any known problems or limitations of your system.
the patterns dont include context so they just fill with common patterns